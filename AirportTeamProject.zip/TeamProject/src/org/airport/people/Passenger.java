package org.airport.people;
import org.airport.hardware.*;

public class Passenger extends Person {
	
	private String id; 			 //String or Int??
	private String assignedSeat;
	private Flight assignedFlight;
	
	public Passenger() {
		this.id = "unknown";
		this.assignedSeat = "unknown";
		this.assignedFlight = null;
		
	}
	
	public String getID() {
		return id;
	}
	
	public void setID(String id) {
		this.id = id;
	}
	
	public void setAssignedSeat(String seat) {
		assignedSeat = seat;
	}
	
	public String getAssignedSeat() {
		return this.assignedSeat;
	}
	
	public Flight getFlight() {
		return this.assignedFlight;
	}
	
	public void setFlight(Flight flight) {
		assignedFlight = flight;
	}
	
	// add boarding pass
}
