package org.airport.people;

public class Person {

	private String name;
	
	public Person() {
		this.name ="unknown";
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String aName) {
		this.name = aName;
	}
	
}
