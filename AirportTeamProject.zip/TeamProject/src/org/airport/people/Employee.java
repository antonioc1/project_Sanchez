package org.airport.people;

public class Employee extends Person {

	private String id;
	private String title;
	
	public Employee() {
		id = "unknown";
		title = "unknown";
	}
	
	public String getID() {
		return this.id;
	}
	
	public void setID(String id) {
		this.id = id;
	}
	
	public String getTitle() {
		return this.title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
}
