package org.airport.people;

import java.util.ArrayList;

public class AirportStaff extends Employee {
	
	private ArrayList<String> responsibility;
	
	public AirportStaff() {
		responsibility = null;
	}
	
	public void addResponsibility(String r) {
		responsibility.add(r);
	}
	
	public void removeResponsibility(String r) {
		responsibility.remove(r);
	}
	
	
}
