package org.airport.people;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class EmployeeGUI extends JFrame {
	
	private JButton okButton;
	private JButton cancelButton;
	private JFrame empFrame;
	private JTextField empID;
	
	public EmployeeGUI() {
//		super();
//		
//		setSize(300,300);
//		setLayout(new FlowLayout(FlowLayout.CENTER));
//		
//		add(new JLabel("Employee Login"));
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		buildGUI();
	
	}
	
	public void buildGUI() {
		JLabel empLabel = new JLabel("Employee ID:");
		empID = new JTextField(10);
		okButton = new JButton("OK");
		cancelButton = new JButton("Cancel");
		empFrame = new JFrame("Employee Login");
		
		empFrame.setSize(300, 100);
		JPanel empPanel = new JPanel();
		
		empPanel.add(empLabel);
		empPanel.add(empID);
		empPanel.add(okButton);
		empPanel.add(cancelButton);
		
		okButton.addActionListener(new ButtonListener());
		cancelButton.addActionListener(new ButtonListener());
		
		empFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		empFrame.add(empPanel);
		empFrame.setResizable(false);
		empFrame.setLocationRelativeTo(null);
		empFrame.setVisible(true);

	}
	
	private class ButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JButton source = (JButton)(e.getSource());
			
			if(source.equals(okButton)) {
				handleEmployeeLogin(empID.getText());
			}
			else if(source.equals(cancelButton)) {
				empFrame.dispose();
			}
		}
	}
	
	public void handleEmployeeLogin(String ID) {
		if(0 == 1) { 			// if matches with staff ID's
			
		}
		else if(0 == 1) { 		// if matches with flight crew
			
		}
		
		else {
			JOptionPane.showMessageDialog(null,
					"Incorrect ID. Try Again.",
					"Error ",
					JOptionPane.PLAIN_MESSAGE);
		}
	}

}
