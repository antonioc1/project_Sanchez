package org.airport.people;
import org.airport.hardware.*;


// Test driver by Lahiru Ariyananda

public class Driver1 {
	
	public static void main(String[] args){
		EmployeeGUI empGUI = new EmployeeGUI();    
		
	}
}
