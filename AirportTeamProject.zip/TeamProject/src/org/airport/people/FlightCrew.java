package org.airport.people;

import org.airport.hardware.*;

public class FlightCrew extends Employee{
	
	private Flight assignedFlight;
	
	public FlightCrew() {
		assignedFlight = null;
	}
	
	public int reportDelay() {
		return 1;       // fix me
	}
	
	public Flight getFlight() {
		return this.assignedFlight;
	}
	
	public void setFlight(Flight flight) {
		this.assignedFlight = flight;
	}
	
	
}
