package org.airport.hardware;
import java.util.ArrayList;

import org.airport.people.*;

public class Flight {
	private int schedule;
	private int flightNum;
	private ArrayList<FlightCrew> crewList;
	private String plane;
	private ArrayList<Passenger> passenger;
	private ArrayList<String> seats;
	
	
	public int getSchedule() {
		return schedule;
	}
	public void setSchedule(int schedule) {
		this.schedule = schedule;
	}
	public int getFlightNum() {
		return flightNum;
	}
	public void setFlightNum(int flightNum) {
		this.flightNum = flightNum;
	}
	public String getPlane() {
		return plane;
	}
	public void setPlane(String plane) {
		this.plane = plane;
	}
	
	public void addCrewList(FlightCrew aCrew) {
		this.crewList.add(aCrew);
	}
	
	public void removeCrewList(FlightCrew aCrew) {
		this.crewList.remove(aCrew);
	}
	
	public void addPassenger(Passenger p) {
		this.passenger.add(p);
	}
	
	public void removePassenger(Passenger p) {
		this.passenger.remove(p);
	}
	
	public void addSeat(String s) {
		this.seats.add(s);
	}
	
	public void removeSeat(String s) {
		this.seats.remove(s);
	}

}
