package org.airport.hardware;

import java.util.ArrayList;
import org.airport.people.*;

public class Gate {
	
	private String gateNum;
	private Terminal assignedTerminal;
	private ArrayList<Flight> schedule;
	
	public void setNum(String name) {
		
		this.gateNum = name;
	}
	
	public String getNum() {
		
		return this.gateNum;
	}
	
	public void assignTerminal(Terminal terminal) { // need to detect conflicts
		
		this.assignedTerminal = terminal;
	}
	
	public void addFlight(Flight flight) { // need to detect conflicts
		
		schedule.add(flight);
	}
	
	public void removeFlight(Flight flight) { // need to detect conflicts
		
		schedule.remove(flight);
	}
	
	public void detectConflict() {
		
		// still need to write this need other classes.
	}

}
