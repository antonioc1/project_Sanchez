package org.airport.hardware;

import java.util.ArrayList;

import org.airport.hardware.Airline;
import org.airport.people.*;

public class Airport {
	private ArrayList<Airline> airlines;	// Airline not implmented
	private ArrayList<Employee> employees;		// Employee not implemented
	private String name;
	private String address;
	private ArrayList<Terminal> terminals;	// Terminal not implemented
	private int maxTerminals;	// max number of terminals
	private int terminalCount;	// current number of active terminals
	
	public Airport() 
	{
		airlines = new ArrayList<Airline>();
		employees = new ArrayList<Employee>();
		name = "";
		address = "";
		terminals = new ArrayList<Terminal>();
		maxTerminals = 0;
		terminalCount = 0;
		
	}
	
	public void addAirline(Airline airline) // Adds airline to list, implement check to make sure airline is not already in list
	{
		if(checkAirline(airline) != true) // Checks to make sure airline is not added twice
		{
			airlines.add(airline);
		}
		else
		{
			// Print error message ("Already in list")
		}
	}
	
	public void removeAirline(Airline airline) // Removes airline from list
	{
		if(checkAirline(airline) == true) // Checks to make sure airline is in list
		{
			airlines.remove(airline);
		}
		else
		{
			// Print error message ("Not in list")
		}
	}
	
	public ArrayList<Airline> getAirlines()	// Returns the list of airlines
	{
		return airlines;
	}
	
	public void addEmployee(Employee employee) // Add employee to list, implement check to make sure employee is not already in list
	{
		if(checkEmployee(employee) != true)
		{
			employees.add(employee);
		}
		else
		{
			// Print error message ("Already in list")
		}
	}
	
	public void removeEmployee(Employee employee) // Remove employee from list
	{
		if(checkEmployee(employee) == true)
		{
			employees.remove(employee);
		}
		else
		{
			// Print error message ("Not in list")
		}
	}
	
	public void listEmployee() // list employees
	{
		System.out.println("Airport Employee List:");
		for(Employee e : employees)
		{
			System.out.println(e.getName());
		}
	}
	
	public String getAirportName()	// Return airport name
	{
		return name;
	}
	
	public void setAirportName(String name)	// Set airport name
	{
		this.name = name;
	}
	
	public String getAddress()	// Return address
	{
		return address;
	}
	
	public void setAddress(String address) {	// Set the address
		this.address = address;
	}
	
	public void addTerminal(Terminal terminal)	// Add terminal to list, implement check
	{
		if(checkTerminal(terminal) != true)
		{
			terminals.add(terminal);
			// implement terminal count check with max
			++terminalCount;
		}
		else
		{
			// Print error message ("Terminal already in list")
		}
	}
	
	public void removeTerminal(Terminal terminal) // Remove terminal from list
	{
		if(checkTerminal(terminal) == true)
		{
			terminals.remove(terminal);
			--terminalCount;
		}
		else
		{
			// Print error message ("Terminal not in list")
		}
	}
	
	public void listTerminals()	// list terminals
	{
		System.out.print("Terminal List:");
		for(Terminal t : terminals) 
		{
			System.out.print(t.getName());
		}
	}
	
	public void setMaxTerminals(int max)	// Can only set max once and can only be set by an administrator 
	{
		maxTerminals = max;
	}
	
	public int getMaxTerminals()	// Return max number of terminals
	{
		return maxTerminals;
	}
	
	public boolean checkAirline(Airline airline)	// Checks if airline is in list, returns true if its inside the list
	{
		boolean i = false;	// Assume not in list
		for(Airline a : airlines)	// For loop to check list
		{
			if(airline.getName().equals(a.getName()))
			{
				i = true;
			}
		}
		return i;
	}
	
	public boolean checkEmployee(Employee employee)	// Checks if employee is in list, returns true if their in the list
	{
		boolean i = false;
		for(Employee e : employees)
		{
			if(employee.getName().equals(e.getName()))
			{
				i = true;
			}
		}
		return i;
	}
	
	public boolean checkTerminal(Terminal terminal)
	{
		boolean i = false;
		for(Terminal t : terminals)
		{
			if(terminal.getName().equals(t.getName()))
			{
				i = true;
			}
		}
		return i;
	}
}
