package org.airport.hardware;

import org.airport.people.*;

import java.util.ArrayList;


public class Airline {
	private String name;
	private ArrayList<Employee> employeeList;
	private ArrayList<Gate> gateList;
	private int maxGates;
	
	public Airline()
	{
		name = "";
		employeeList = new ArrayList<Employee>();
		gateList = new ArrayList<Gate>();
		maxGates = 0;
	}
	
	public String getName()	// Returns name of airline
	{
		return name;
	}
	
	public void setName(String name) // Sets the name of the airline
	{
		this.name = name;
	}
	
	public void addEmployee(Employee employee) // Add employee to list, implement check to make sure employee is not already in list
	{
		if(checkEmployee(employee) != true)
		{
			employeeList.add(employee);
		}
		else
		{
			// Print error message ("Already in list")
		}
	}
	
	public void removeEmployee(Employee employee) // remove employee
	{
		if(checkEmployee(employee) == true)
		{
			employeeList.remove(employee);
		}
		else
		{
			// Print error message ("Not in list")
		}
	}
	
	public void listEmployee()	// list employees
	{
		System.out.print("Employee List:");
		for(Employee e : employeeList)
		{
			System.out.print(e.getName());
		}
	}
	
	public void addGate(Gate gate)	// add gate to list
	{
		if(checkGate(gate) != true)
		{
			gateList.add(gate);
		}
		else
		{
			// Print error message ("Already in list")
		}
	}
	
	public void removeGate(Gate gate)	// remove gate from list
	{
		if(checkGate(gate) == true)
		{
			gateList.remove(gate);
		}
		else
		{
			// Print error message ("Not in list")
		}
	}
	
	public void listGate()	// list gates
	{
		System.out.print("Gate List:");
		for(Gate g : gateList)
		{
			System.out.print(g.getNum());
		}
	}
	
	public void setMaxGates(int max)
	{
		maxGates = max;
	}
	
	public boolean checkEmployee(Employee employee)	// Checks if employee is in list, returns true if their in the list
	{
		boolean i = false;
		for(Employee e : employeeList)
		{
			if(employee.getName().equals(e.getName()))
			{
				i = true;
			}
		}
		return i;
	}
	
	public boolean checkGate(Gate gate)
	{
		boolean i = false;
		for(Gate g : gateList)
		{
			if(gate.getNum().equals(g.getNum()))
			{
				i = true;
			}
		}
		return i;
	}
}
