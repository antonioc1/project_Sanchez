package org.airport.hardware;
import java.util.ArrayList;
import org.airport.people.*;



public class Terminal {
	
	private String name;
	private ArrayList<Gate> gateList;
	
	public void setName(String name) {
		
		this.name = name;
	}
	
	public String getName() {
		
		return this.name;
	}
	
	public void addGate(Gate gate) { // error check / conflict check needed
		
		gateList.add(gate);
	}
	
	public void removeGate(Gate gate) { // still need error checking and conflict checking
		
		gateList.remove(gate);
	}

}
